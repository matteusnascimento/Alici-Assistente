
def get_ai_response(message):
    return f"Você disse: {message} (resposta gerada pela IA)"
